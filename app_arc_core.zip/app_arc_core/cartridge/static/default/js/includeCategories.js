/**
 *    This file is used to get the dynamic catageries available in the RedCross - SFCC site  
 */

var scriptenvURL = window.evnURL != undefined ? window.evnURL : "production-shop-arc.demandware.net";
	service = {},
	$protocal = window.location.protocol,
	window.geolocation = {},
	loadGoolge = window.loadGoogleSuggestions == undefined ? true : window.loadGoogleSuggestions,
	window.currentaddress = "";
	if($protocal.indexOf('file') != -1){ $protocal = "https:"  }

function getCategoryList() {
	//alert($protocal);
	//$('.select-class').html();
	var startOption = "<option value='Select a Class Type'>Select a Class Type </option>" ;
	var optionStart = "<option value=";
	 
	var optionEnd = "</option>";
	
	$.ajax({
	    url: $protocal+"//"+scriptenvURL+"/on/demandware.store/Sites-RedCross-Site/default/Home-CategoriesList",
	    dataType: 'jsonp',
	    success : function(data) {  
			 if(data != null) {
				 var obj = JSON.parse(data);
				 var arr = obj["catItems"];
				 var postalCode = obj["postalCode"];
				 var googlekey = obj["googlekey"];
				 if(arr.length == 0){
					 $('.class-wrapper, .geo-complete-input').hide();
					 $('.home-find-classes-form').attr('action', $protocal+"//"+scriptenvURL+"/on/demandware.store/Sites-RedCross-Site/default/Home-Show");
					 	if ($('#cat-dem-select')) {
			                $('#cat-dem-select').hide();
						}
					 	if(postalCode != ''){
					 		$('#headernavgeolocation').val(postalCode);
					 	} else {
					 		$('#headernavgeolocation').val('20002');
					 	}
						
						$('#headernavgeolocation').hide();  
					 return false;
				 }
				 if(loadGoolge) {
					 if(googlekey != null && typeof google == "undefined") {
						  	var s = document.createElement('script');
						  		s.setAttribute('src', $protocal+'//maps.googleapis.com/maps/api/js?key='+ googlekey +'=&libraries=places');
						        s.setAttribute('type', 'text/javascript');
						        s.setAttribute('id', 'mapscript');
						        document.getElementsByTagName('head')[0].appendChild(s);
						 }
						 
						 if(typeof google == "undefined"){
							 $('#mapscript').load(function(){
								 initSuggestion();
							 });
						 } else {
							 initSuggestion();
						 }
						  
				 }else{
					 initSuggestion();
				 }
				 
				  for(var ii=0;ii<arr.length;ii++) {
					  startOption = startOption+""+optionStart+"'"+arr[ii].id+"'>"+arr[ii].name+""+optionEnd;
                  } 
				  $('.select-class').html(startOption);
				   
				 /*
				  * Fix for RCOPHSS-4313 
				  * 
				  *  if(postalCode != 'null' ) {
					$('.postalcode').val(postalCode);
				  }*/ 
			 } 
			},
		error:function(e) {
			alert('Error while getting the categories....');
		}
	});
} 

function  displaySuggestions(predictions, status, ele) {
   if (status != google.maps.places.PlacesServiceStatus.OK) {
     return;
   }
   if($(ele).parent().find('.autocomplete-results').length == 0){
	   $(ele).parent().append('<ul class="autocomplete-results" style="display: none"></div>');
   }
   
   $(ele).parent().find('.autocomplete-results').empty();
   
   predictions.forEach(function(prediction) {
      $(ele).parent().find('.autocomplete-results').append('<li data-lat>'+ prediction.description +'</li>');
   });
   $(ele).parent().find('.autocomplete-results li:last-child').after('<div class="use-current-location"><span class="geo-arrow"></span><span class="use-location">Use my location</span></div>');
   $('.autocomplete-results .use-current-location').css('border-top', 'solid 1px #d6d6d6');
};

function currentLocation(){
  if (navigator.geolocation) {  
      navigator.geolocation.getCurrentPosition(function (position) {         
         window.geolocation = {
                 lat: position.coords.latitude,
                 lng: position.coords.longitude
         }; 
      });
  } 
}

function currentAddress(){
     navigator.geolocation.getCurrentPosition(function (position) {
         $.getJSON({
             url: $protocal+"//maps.googleapis.com/maps/api/geocode/json?latlng="+position.coords.latitude+","+position.coords.longitude + '&key=' + SitePreferences.GOOGLE_API_KEY,
             callback: function (data) {
               $.each(data.results[0].address_components, function(i,v){
                      if(v.types[0] == "country" || v.types[0] == "administrative_area_level_1" || v.types[0] == "locality"){
                             if(window.currentaddress.length == 0){
                                   window.currentaddress = v.types[0] == "administrative_area_level_1" ? v.short_name : v.long_name;
                            }else{
                                   window.currentaddress += ', '+(v.types[0] == "administrative_area_level_1" ? v.short_name : v.long_name);
                             }
                      }
                      });
               if(window.currentaddress != '' && !($('.global-header-main').find('input[name="seslatlong"]').val())){
                      $('.geo-complete-input').val(window.currentaddress);
                      var $geo_cont = $('.geo-complete-results');
                      $geo_cont.find('.geo-complete-lat').val(window.geolocation.lat);
                      $geo_cont.find('.geo-complete-lng').val(window.geolocation.lng);
               }else{
               	   $('.geo-complete-input').val($('.geo-akmai').val());
               	   var $geo_cont = $('.geo-complete-results');
                      $geo_cont.find('.geo-complete-lat').val($('.geo-latitude').val());
                      $geo_cont.find('.geo-complete-lng').val($('.geo-longitude').val());
               }
             }
        });
      });
	     if(window.currentaddress != '' && !($('.global-header-main').find('input[name="seslatlong"]').val())){
	       $('.geo-complete-input').val(window.currentaddress);
	       	 var $geo_cont = $('.geo-complete-results');
	       	 $geo_cont.find('.geo-complete-lat').val(window.geolocation.lat);
	       	 $geo_cont.find('.geo-complete-lng').val(window.geolocation.lng);
	   }else{
	   	   $('.geo-complete-input').val($('.geo-akmai').val());
		   	 var $geo_cont = $('.geo-complete-results');
	         $geo_cont.find('.geo-complete-lat').val($('.geo-latitude').val());
	         $geo_cont.find('.geo-complete-lng').val($('.geo-longitude').val());
	   }
}


function initSuggestion(){
   //on load set current state information
   //currentLocation();
   //currentAddress();
	if(loadGoolge) {
	setTimeout(function(){
		service = new google.maps.places.AutocompleteService();
	},3000);
	}	
	
	
   $('.class-hero .class-search.cat-search,.header-class-search.cat-search,.search-tabs .class-search.cat-search').on('change', function(){
   	if($('span.validate-message').length > 0) {
			$('span.validate-message').remove();
			$(this).closest('div.cat-search').find('.custom-select .selected-option').removeClass('error');
		}
   });
   
   $('.geo-complete-input').each(function(){
	   if($(this).parent().find('.autocomplete-results').length == 0){
		   $(this).parent().append('<ul class="autocomplete-results" style="display: none"></div>');
	   }
   });
   
   //click events on autocomplete text and populates lat,long values.
   $(document).on('keyup', '.geo-complete-input', function(e){ 
        var $this = $(this);
        if($(this).val() == "" || !loadGoolge){ 
       	 return false;
        }
        if(typeof service.getPlacePredictions != "undefined"){
        	service.getPlacePredictions({ input: $(this).val() , componentRestrictions : {country: 'US'} }, function(predictions, status){
            	displaySuggestions(predictions, status, $this);
            });
        }
     }).on('change','.class-hero .class-search.cat-search,.header-class-search.cat-search,.search-tabs .class-search.cat-search', function(){
   	  if($('span.validate-message').length > 0) {
             $('span.validate-message').remove();
   	  }
     }).on('click', '.home-find-classes-form button', function(e){
   	  if($(this).closest('.cat-search').find('.select-class').val() == "Select a Class Type" && $(this).closest('.cat-search').find('.geo-location').val() != "" ) {
             return true;                  
         }
   	  else
   	  { 
         e.preventDefault();
         if($('.autocomplete-results').is(':visible')) {
       	  $('body').find('ul.autocomplete-results').hide();
         }
         if($(this).closest('.cat-search').find('span.validate-message').length > 0) {
             $(this).closest('.cat-search').find('span.validate-message').remove();
         }      
         if($(this).closest('.cat-search').find('.select-class').val() == "Select a Class Type"){
             $('<span/>').attr('class', 'validate-message').appendTo($(this).closest('div.cat-search').find('.custom-select'));
           $(this).closest('div.cat-search').find('.custom-select .selected-option').addClass('error');
             $('span.validate-message').text('Please select a Class Type');
       }else{
             $('<span/>').attr('class', 'validate-message').appendTo($(this).closest('div.cat-search').find('.header-geo-field'));
           $(this).closest('div.cat-search').find('.header-geo-location .geo-complete-input').addClass('error');
             $('span.validate-message').text('Please select Location');
       }
			return false;
         } 
     }).on('blur', '.geo-complete-input', function(e){
   	  //	$(this).siblings('.autocomplete-results').hide();
     }).on('focusin', '.geo-complete-input', function(e){
   	  if($('span.validate-message').length > 0) {
   		     $('span.validate-message').remove();
   	  	 }
   	  $('.geo-complete-input').val('');
     	  if($('.geo-complete-input').val().trim() == ''){
     		$('body').find('ul.autocomplete-results li').empty();
     		$(this).parent().find('.autocomplete-results').show();
     		$('body').find('ul.autocomplete-results .use-current-location').css('border-top', 'none').show();
     	  }
	      	  
     }).on('click', '.autocomplete-results li', function(e){
        var $val = $(this).text(),
        $geo_cont = $(this).parent();
        $(this).parent().siblings('.geo-complete-input').val($val);
        $(this).parent().hide();
        if(!loadGoolge){ return false; }
       // if($protocal.indexOf('file') != -1 || $protocal.indexOf('http:')){ return; }
        $.ajax({
        	url: $protocal+"//maps.googleapis.com/maps/api/geocode/json?address="+$val+ '&key=' + SitePreferences.GOOGLE_API_KEY,
             success: function (data) {
                
            	 if(data.status == "OK"){
                    $('.geo-complete-lat').val(data.results[0].geometry.location.lat);
                    $('.geo-complete-lng').val(data.results[0].geometry.location.lng);
            	 } else {
                    if(geolocation == undefined){return;}
                   $('.geo-complete-lat').val(geolocation.lat);
                   $('.geo-complete-lng').val(geolocation.lng);
            	 }
            },
            error: function (e) {
            	console.log('error:-'+e);
            }
        }); 
         
     }).on('click', '.use-current-location .use-location,.geo-arrow, .header-geo-icon', function(){
   	  $(this).parent().hide();
   	  if($('span.validate-message').length > 0) {
   		  $('span.validate-message').remove();
   	  }
   	  
   	  if(window.currentaddress!=""){
   		  $(this).parent().find('.geo-complete-input').val(window.currentaddress);
   		  $(this).parent().find('.geo-complete-lat').val(window.geolocation.lat);
       	  $(this).parent().find('.geo-complete-lng').val(window.geolocation.lng);
   	  }else{
   		  $(this).parent().find('.geo-complete-input').val($('.geo-akmai').val());
   		  $(this).parent().find('.geo-complete-lat').val($('.geo-latitude').val());
   		  $(this).parent().find('.geo-complete-lng').val($('.geo-longitude').val());
   	  }
        $('body').find('ul.autocomplete-results li').empty();
         $('body').find('ul.autocomplete-results .use-current-location').css('border-top', 'none').hide();
     });
}

$(document).ready(function () { // trigger after DOM loads
    getCategoryList();
});	
