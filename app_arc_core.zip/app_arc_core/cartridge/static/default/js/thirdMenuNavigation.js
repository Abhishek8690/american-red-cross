'use strict';
$(document).ready(function() {
	   $('.navigation').append($('.user-panel'));
	   $('.navigation').append($('.header-find-a-class'));
	   $('.navigation .header-find-a-class').show();
//for the mobile navigation
if($(window).width() < 1024) {
	$('.menu-toggle').on('click', function () {
		if($('.navigation').hasClass('new-menu')) {
            $('.mobile-menu-overlay').show();
            $('.mobile-nav-close.third-menu').show();
		}
    });
	
	$('.menu-category li.submenu').on('click', function (e) {
		e.stopPropagation();
		e.preventDefault();
		var $parentLi = $(this);
		if($parentLi.hasClass('supplies-products')) {
			$('.top-menu-category').find('h2').hide();
		}
		if($parentLi.children().filter('span.mobile-grouping').children().filter('.fa.menu-item-toggle').length || $parentLi.children().filter('i.menu-item-toggle').length) {
			var id = $parentLi.attr('id');
			if(id == 'main-2') {
				$('.top-menu-category.open h2').hide();
			}
		}
	});
	
	$('.back-to-supplies').on('click', function() {
		var id = $(this).attr('id');
		if(id=='main-1') {
			if($('#main-1.supplies-products').hasClass('active')) {
				$('.top-menu-category h2').hide();
			} else {
				$('.top-menu-category h2').show();
			}
		} else if(id=='main-2') {
			$('.top-menu-category h2').hide();
		}
	});

    // removing the overlay on click of X in the mobile view
    $('.mobile-nav-close.third-menu .fa').on('click',function(){
    	$('.mobile-menu-overlay').hide();
    	$('.mobile-nav-close.third-menu').hide();
    	$('.top-menu-category').removeClass('open');
    	$('.top-menu-category h2').show();
        $('.navigation .menu-category li').removeClass('active block forceHide');
        $('.menu-category li').addClass('submenu');
        $('.navigation').removeClass('active block');  
        $('.back-to-supplies').removeClass('active block');
        $('li#main-1, li#main-2, li#main-3, li#main-4, li#main-5, .navigation li a, .menu-category li a, .menu-category').removeClass('active forceHide');
        $('li#main-1, li#main-2, li#main-3, li#main-4, li#main-5, .menu-category li, .menu-category li a, .menu-category, span.mobile-grouping').removeAttr('style');
        $('ul#main-2, ul#main-3, ul#main-4, ul#main-5').removeClass('block');
        $('.level-2, .level-3, .level-4, .level-5').removeAttr('style');
    	$('.navigation').removeClass('active');
    	$('.navigation').hide();
        $('#wrapper').removeClass('menu-active');
        if($(window).width() > 767) {
            $('.navigation').show();
        }
        $('body').removeClass('fixed');
    });
}

//mobile navigation ends here

});




















