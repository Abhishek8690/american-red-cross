'use strict';

var dialog = require('./dialog'),
    page = require('./page'),
    util = require('./util'),
    validator = require('./validator');

var login = {
    /**
     * @private
     * @function
     * @description init events for the loginPage
     */
    init: function () {
    	//add class to prevent strikeiron
    	$('input[name*="login_username"]').addClass('nostrike');
    	
        //o-auth binding for which icon is clicked
        $('.oAuthIcon').bind('click', function () {
            $('#OAuthProvider').val(this.id);
        });
    

        //toggle the value of the rememberme checkbox
        $('#dwfrm_login_rememberme').bind('change', function () {
            if ($('#dwfrm_login_rememberme').attr('checked')) {
                $('#rememberme').val('true');
            } else {
                $('#rememberme').val('false');
            }
        });
        
        $('#password-reset').on('click', function (e) {
            e.preventDefault();
            dialog.open({
                url: $(e.target).attr('href'),
                options: {
                	dialogClass : 'forget-password',
                	 width: '600px',
                    open: function () {
                        validator.init();
                        util.lableFocus();
                        $('.forget-password').find('.input-text.email').closest('.form-row').find('label').addClass('focus');
                        $('.forget-password').find('label').closest('.form-row').addClass('form-label');
                        var $requestPasswordForm = $('[name$="_requestpassword"]'),
                        $submit = $requestPasswordForm.find('[name$="_requestpassword_send"]');
                        $('body').off('click', 'button[name$="requestpassword_send"]').on('click', 'button[name$="requestpassword_send"]', function(e) {
                        	e.preventDefault();
                        	if (!$requestPasswordForm.valid()) {
                                return;
                            }
                            var data = $requestPasswordForm.serialize();
                            // add form action to data
                            data += '&' + $submit.attr('name') + '=';
                            // make sure the server knows this is an ajax request
                            if (data.indexOf('ajax') === -1) {
                                data += '&format=ajax';
                            }
                            var curEmail = $('#PasswordResetForm input.email').val();
                            $('#PasswordResetForm input.email').val(curEmail);
                            $.ajax({
                                type: 'POST',
                                url: util.appendParamToURL($requestPasswordForm.attr('action'),'email',curEmail),
                                data: data,
                                success: function (response) {
                                    if (typeof response === 'object' &&
                                            !response.success &&
                                            response.error === 'CSRF Token Mismatch') {
                                        page.redirect(Urls.csrffailed);
                                    } else if (typeof response === 'string') {
                                    	$('#PasswordResetForm input.email').val(curEmail);
                                    	dialog.$container.html(response);
                                        util.lableFocus();
                                        $('#dialog-container').on('click', '.pwdresetbutton', function (e) {
                                            e.preventDefault();
                                            dialog.close();
                                        });
                                    }
                                },
                                failure: function () {
                                    dialog.$container.html('<h1>' + Resources.SERVER_ERROR + '</h1>');
                                }
                            });
                        });
                    }
                }
            });
            util.lableFocus();
        });
    }
}

module.exports = login;
