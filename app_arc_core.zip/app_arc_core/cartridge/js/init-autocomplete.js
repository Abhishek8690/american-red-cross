'use strict';

module.exports = {
	geoLocationInit : geoLocationInit,
	geoLocationUpdate : geoLocationUpdate
};

var autoComplete = require('./autocomplete'),
	util = require('./util'),
	componentForm,
	googleAPIKey = SitePreferences.GOOGLE_API_KEY;

//Start the Geo location auto-complete
function geoLocationInit() {
	var isAPILoaded = window.autocompleteIsLoaded,
	 	apiLoadFailure = window.apiLoadFailure;
	
	if (googleAPIKey != '') {
		if(!isAPILoaded) {			
			autoComplete.loadApi(googleAPIKey); 
		}
		if(apiLoadFailure) {
			return;
		}
		autoComplete.geolocate();
		componentForm = autoComplete.initAutocompletetoInputField();
	  }
}

// Updates the Geo location (City/Zip) with Latlng
function geoLocationUpdate($location) {
	var location = $location;
	 var protocol = window.location.protocol;
	 if (googleAPIKey != '') {
		 //caching to avoid loading multiple instances of the api per session
		 $.ajax({
			 url: protocol + '//maps.googleapis.com/maps/api/geocode/json?address=' + location + '&key=' + googleAPIKey,
			 cache: true,
			 dataType: 'JSON',
			 success: function (response){
				 window.autocompleteIsLoaded = true;
				 var changeLat = response.results[0].geometry.location.lat;
				 var changeLon = response.results[0].geometry.location.lng;
				 
				 var url = util.appendParamsToUrl(Urls.geoLocationSession,{GeoLatitude: changeLat, GeoLongitude: changeLon, format: 'ajax' });
				 $.ajax({ 
					 url: url,
					 method: 'POST',
					 success: function (){
					 },
					 error: function(){
					 }
				 });
				 
			 },
			 error: function () {
				 window.apiLoadFailure = true;
			 }
		 });
	 }
}