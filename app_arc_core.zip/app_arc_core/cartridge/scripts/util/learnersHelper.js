'use strict';

var Site = require('dw/system/Site');

//add a new learner to the profile whether its already empty or not.
//NOTE: you will need to call the service for creating a customer as well.
exports.addNewLearner = function(profile,learner){
	let list;
	if(empty(profile.custom.learnerList)){
		list = {};
	}else{
		list = JSON.parse(profile.custom.learnerList);
	}
	if(list[learner.email]){
		return;
	}

	list[learner.email] = learner;
	list[learner.email].customerNo = profile.customerNo + '-' + Object.keys(list).length;
	writeCustomer(profile, list);

	return;
}

//update the existing learner.
//NOTE: you will need to call the saba service for updating a learner as well
exports.updateLearner = function(profile, learner){
	let list = JSON.parse(profile.custom.learnerList);
	if(!(learner.email in list)){
		return;
	}
	
	list[learner.email] = learner;
	writeCustomer(profile, learner);
	return list[learner.email];
}


//gets learner for a given profile
exports.get = function(profile, email){
	if(empty(profile.custom.learnerList)){
		return;
	}
	let list = JSON.parse(profile.custom.learnerList);
	if(!list[email]){
		return;
	}
	
	return list[email];
}


//udpate the saba learner id for a given learner
exports.updateSabaInternalId = function(profile, email, lmsInternalId){
	let list = JSON.parse(profile.custom.learnerList);
	if(!list[email]){
		return;
	}
	list[email].lmsInternalId = lmsInternalId;
	writeCustomer(profile, list);
	
	return list[email];
}


//util private method for wrapping the profile update in a transaction
function writeCustomer(profile, data){
	let txn = require('dw/system/Transaction');
	txn.begin();
		profile.custom.learnerList = JSON.stringify(data);
	txn.commit();
}


//constructor
exports.learner = function(fname, lname, email, number, lmsId){
	return {
		'firstName' : fname || '',
		'lastName' : lname ||'',
		'email' : email || '',
		'customerNo' : number || null,
		'lmsInternalId' : lmsId || null
	}
}

module.exports = exports;