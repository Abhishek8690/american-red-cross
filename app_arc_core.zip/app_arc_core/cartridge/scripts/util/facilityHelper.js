'use strict';
//q=lifeguarding&prefn1=facilityID&prefv1=sanfranfacility|saltlakefacility

var Logger = require('dw/system/Logger');
var Site = require('dw/system/Site');

exports.getStores = function(lat, long, miles){
	let mgr = require('dw/catalog/StoreMgr'),
		stores;
	if (!empty(lat) && !empty(long) && !empty(miles)) {
		
		try {
			stores = mgr.searchStoresByCoordinates(Number(lat), Number(long), 'mi', miles);
		} catch (e) {
			// TODO: handle exception
			var err = e ;
		}
		
	}
	if('onlinecoursefacilityid' in Site.getCurrent().preferences.custom && !empty(Site.getCurrent().preferences.getCustom().onlinecoursefacilityid)){
		var onlineFacilityID = Site.getCurrent().preferences.getCustom().onlinecoursefacilityid;
		stores.put(onlineFacilityID,"");
	}
	return stores; 
};
exports.getStoresByPostalCode = function(country,zip,miles){
	let mgr = require('dw/catalog/StoreMgr'),
		stores;
	 
	if (!empty(zip) && !empty(miles)) {
		try {
		 	stores = mgr.searchStoresByPostalCode(country, zip, "mi", Number(miles));
		} catch (e) {
			// TODO: handle exception
			var err = e ;
			if(Logger.isErrorEnabled()) {
				Logger.error("\n facilityHelper.js:getStoresByPostalCode() -There is an erro while fetching the stores"+e.message);
			}
			
		}
		
	}
	if('onlinecoursefacilityid' in Site.getCurrent().preferences.custom && !empty(Site.getCurrent().preferences.getCustom().onlinecoursefacilityid)){
		var onlineFacilityID = Site.getCurrent().preferences.getCustom().onlinecoursefacilityid;
		stores.put(onlineFacilityID,"");
	}
	 
	return stores;
};

var getCourseIDs = function(category){
	let ids = [];
	let coursesItr = category.getOnlineProducts().iterator();
	
	while (coursesItr.hasNext()) {
		let course = coursesItr.next();
		ids.push(course.ID);	
	}

	return ids;
	
};

//expose helper
exports.getCourseIDs = getCourseIDs;


//returns a unique list of courseids for a given list of categories
exports.getCourseIDsFromList = function(catlist){
    let ids = [];
    let seen = {};
    for(x in catlist){
        ids = ids.concat(getCourseIDs(catlist[x]).filter(function(id){
            return seen.hasOwnProperty(id) ? false : (seen[id] = true);
        }));
    }    
    return ids;
};


exports.getFacilityIDRefinementString = function(stores){
	let index = 0;
	let ids = [];
	
	for(var x in stores){
		ids.push(x.ID);
	}
	
	//Appending Online facility ID
	if('onlinecoursefacilityid' in Site.getCurrent().preferences.custom && !empty(Site.getCurrent().preferences.getCustom().onlinecoursefacilityid)){
		var onlineFacilityID = Site.getCurrent().preferences.getCustom().onlinecoursefacilityid;
		ids.push(onlineFacilityID);	
	}
	
	// refining online classes.. for every search.    10 categories.. set online course
	//ids.push('online');
	return ids.join('|');
};


module.exports = exports;