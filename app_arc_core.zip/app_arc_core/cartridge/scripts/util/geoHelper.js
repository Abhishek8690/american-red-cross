'use strict'

/* API Includes */
var Site = require('dw/system/Site');

exports.getLatLong = function(){
	
	let latlong = {};
	//for poc
	//TODO : replace this with the below logic outlined in psuedocode
	//latlong.latitude = 36.114647; //35.7796; 
	//latlong.longitude = -115.172813; //-78.6382;
	//end poc
	
	//choose the right lat/long
	 try {
		//checking session first
		 if ('latlong' in session.custom) {
			var latitudevalue = JSON.parse(session.getCustom().latlong)
			latlong.latitude = latitudevalue.latitude;
			latlong.longitude = latitudevalue.longitude;
			latlong.address = latitudevalue.address;
		} else if(!empty(request.geolocation) && !empty(request.geolocation.countryCode) && request.geolocation.countryCode != 'US') {
			//if not in session, using akamai
			latlong.latitude = 	'defaultLatitude' in dw.system.Site.current.preferences.custom ? dw.system.Site.current.preferences.custom.defaultLatitude : request.geolocation.latitude;
			latlong.longitude = 'defaultLongitude' in dw.system.Site.current.preferences.custom ? dw.system.Site.current.preferences.custom.defaultLongitude : request.geolocation.longitude;
			latlong.address = 	'defaultCity' in dw.system.Site.current.preferences.custom ? dw.system.Site.current.preferences.custom.defaultCity : (request.geolocation.city + ', ' + request.geolocation.regionCode + ', ' + request.geolocation.countryName);
		} else {
				//if not in session, using akamai
				latlong.latitude = request.geolocation.latitude;
				latlong.longitude = request.geolocation.longitude;
				latlong.address = request.geolocation.city + ', ' + request.geolocation.regionCode + ', ' + request.geolocation.countryName;
		}
		//if we have latlong values updating to session
		if ('latitude' in latlong && 'longitude' in latlong) {
			session.custom.latlong = JSON.stringify(latlong);
		} else {
			//if not available, using default lat, lng values of Washington, DC from sitePref
			let lat,
				lng;
			if ('defaultLatitude' in Site.getCurrent().preferences.custom && Site.getCurrent().preferences.getCustom().defaultLatitude != '') {
				lat = Number(Site.getCurrent().preferences.getCustom().defaultLatitude);
			}
			
			if ('defaultLongitude' in Site.getCurrent().preferences.custom && Site.getCurrent().preferences.getCustom().defaultLongitude != '') {
				lng = Number(Site.getCurrent().preferences.getCustom().defaultLongitude);
			}
			if (!empty(lat) && !empty(lng)) {
				latlong.latitude = lat;
				latlong.longitude = lng;
			}
		}
		
	} catch (err){
		latlong.city = 'defaultCity' in dw.system.Site.current.preferences.custom ? dw.system.Site.current.preferences.custom.defaultCity : (request.geolocation.city + ', ' + request.geolocation.regionCode + ', ' + request.geolocation.countryName);
		latlong.state = "";
		latlong.zipCode = 'defaultZipCode' in dw.system.Site.current.preferences.custom ? dw.system.Site.current.preferences.custom.defaultZipCode :  request.geolocation.postalCode;
        latlong.latitude =  'defaultLatitude' in dw.system.Site.current.preferences.custom ? dw.system.Site.current.preferences.custom.defaultLatitude : request.geolocation.latitude;
        latlong.longitude = 'defaultLongitude' in dw.system.Site.current.preferences.custom ? dw.system.Site.current.preferences.custom.defaultLongitude : request.geolocation.longitude;
        latlong.country = !empty(request.geolocation)?request.geolocation.countryCode:'US';
	}
	return latlong;
}


exports.udpateSessionLatLong = function(address, latitude, longitude){
	
	let latlong = {};
	 //TODO :get the latitude and longitude based on the zip provided
	//update session with latitude longitude value
 	if (!empty(latitude) && !empty(longitude) && !empty(address)) {
		
		latlong.latitude = Number(latitude);
		latlong.longitude = Number(longitude);
		latlong.address = address;
		session.custom.latlong = JSON.stringify(latlong);
		
	} else if((!empty(request.httpParameterMap.zip) && !empty(request.httpParameterMap.zip.value)) &&  (!empty(request.httpParameterMap.latitude) && empty(request.httpParameterMap.latitude.value))
					&& (!empty(request.httpParameterMap.longitude) && empty(request.httpParameterMap.longitude.value))) {
		latlong.latitude = "" ;
		latlong.longitude = "" ;
		latlong.address = request.httpParameterMap.zip.value;
		session.custom.latlong = JSON.stringify(latlong);
	}
	
	return latlong;
}

module.exports = exports;