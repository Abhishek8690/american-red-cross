'use strict';
var Site = require('dw/system/Site');
var ArrayList = require('dw/util/ArrayList');
var CustomerGroupHelper={
	isDistributor : false,
	category : null,
	getCategoryForLoggedInGroup : function(){
		return this.getCateogryForCustomer(customer);
	},
	getCateogryForCustomer : function(customer){
		var test = this;
		if(this.category)
			return this.category;
		if(customer.customerGroups.length > 0){
			var cats = customer.customerGroups.toArray().filter(function(item){
				return 'rootCategory' in item.custom && item.custom.rootCategory.length > 0;
			});		
			this.isDistributor = !!cats.length;
			this.category = cats.length > 0 ? dw.catalog.CatalogMgr.getCategory(cats[0].custom.rootCategory) : {ID:null};
		}else{
			this.isDistributor = false;
			this.category = {ID:null};
		}
		return this.category;
	},
	init:function(){
		this.getCategoryForLoggedInGroup();
		return this;
	}
}
module.exports = CustomerGroupHelper.init();