'use strict';

var SuggestModel = require('dw/suggest/SuggestModel');
var ArrayList = require('dw/util/ArrayList');

function getProductSuggestions(suggestModel) {
	var suggestions = suggestModel.getProductSuggestions();
	if (!suggestions) {
		return {
			available: false
		};
	}
	
	// app_pagedesigner_sg starts
	 // Initialize the suggested products / suggested phrases
    var searchPhrasesSuggestions = suggestions.getSearchPhraseSuggestions();
    var suggestedPhrases = searchPhrasesSuggestions.getSuggestedPhrases();
    var suggestedProducts = suggestions.getSuggestedProducts();
    var suggestedPhrasesList = suggestedPhrases.asList();
    // app_pagedesigner_sg ends
    
	return {
		available: suggestions.hasSuggestions(),
		terms: suggestions.getSuggestedTerms(),
		products: suggestions.getSuggestedProducts(),
		phrases: suggestions.getSuggestedPhrases()
	};
}

//app_pagedesigner_sg starts
/**
 * @function getRecentSearchPhrases
 * @param {SuggestModel} suggestModel Represents the suggest model seeded with the user's search query
 * @description Accepts a suggest model -- and returns the collection of recent search phrases
 * @returns {Object} Returns an object describing which recent search phrases exist for the current user
 */
function getRecentSearchPhrases(suggestModel) {

    // Retrieve the recent search suggestions
    var recentSearchPhrases = suggestModel.getRecentSearchPhrases();

    // Were any recent search suggestions found?
    if (!recentSearchPhrases) {
        return {
            available: false
        };
    }

    // Return the recent search phrases
    return {
        available: recentSearchPhrases.hasNext(),
        phrases: recentSearchPhrases
    };

}

/**
 * @function getPopularSearchPhrases
 * @param {SuggestModel} suggestModel Represents the suggest model seeded with the user's search query
 * @description Accepts a suggest model -- and returns the collection of popular search phrases
 * @returns {Object} Returns an object describing which recent popular phrases exist for site
 */
function getPopularSearchPhrases(suggestModel) {

    // Retrieve the popular search phrases for the current site
    var popularSearchPhrases = suggestModel.getPopularSearchPhrases();

    // Were any popular search phrases found?
    if (!popularSearchPhrases) {
        return {
            available: false
        };
    }

    // Return the popular search phrases
    return {
        available: popularSearchPhrases.hasNext(),
        phrases: popularSearchPhrases
    };

}
//app_pagedesigner_sg ends

function getBrandSuggestions(suggestModel) {
	var suggestions = suggestModel.getBrandSuggestions();
	if (!suggestions) {
		return {
			available: false
		};
	}
	return {
		available: suggestions.hasSuggestedPhrases(),
		phrases: suggestions.getSuggestedPhrases()
	};
}

function getContentSuggestions(suggestModel) {
	var suggestions = suggestModel.getContentSuggestions();
	if (!suggestions) {
		return {
			available: false
		};
	}
	return {
		available: suggestions.hasSuggestions(),
		content: suggestions.getSuggestedContent()
	};
}

function getCategorySuggestions(suggestModel) {
	var suggestions = suggestModel.getCategorySuggestions();
	if (!suggestions) {
		return {
			available: false
		};
	}
	return {
		available: suggestions.hasSuggestions(),
		phrases: suggestions.getSuggestedPhrases(),
		categories: suggestions.getSuggestedCategories()
	};
}

function getCustomSuggestions(suggestModel) {
	var suggestions = suggestModel.getCustomSuggestions();
	if (!suggestions) {
		return {
			available: false
		};
	}

	// filter custom phrase that matches exactly the suggested search phrase for products
	var customPhrasesUnfiltered = suggestions.getSuggestedPhrases();
	var customPhrasesFiltered;

	var productSuggestions = suggestModel.getProductSuggestions();
    if (productSuggestions && productSuggestions.hasSuggestedPhrases()) {
        var productPhrase = productSuggestions.getSuggestedPhrases().next().getPhrase();
        var filtered = new ArrayList();
        while (customPhrasesUnfiltered.hasNext()) {
            var customPhrase = customPhrasesUnfiltered.next();
            if (!productPhrase.toUpperCase().equals(customPhrase.getPhrase().toUpperCase())) {
                filtered.push(customPhrase);
            }
        }
        customPhrasesFiltered = filtered.iterator();
    } else {
        // no product suggestions, just pass the custom phrase unfiltered
        customPhrasesFiltered = customPhrasesUnfiltered;
    }

	return {
		available: customPhrasesFiltered.hasNext(),
		phrases: customPhrasesFiltered
	};
}


module.exports = function (searchPhrase, maxSuggestions) {
	var suggestModel = new SuggestModel();
	let custGroupHelper = require('app_arc_core/cartridge/scripts/util/customerGroupHelper');
	let distributorCategory = custGroupHelper.getCategoryForLoggedInGroup();
	suggestModel.setSearchPhrase(searchPhrase);
	suggestModel.setMaxSuggestions(maxSuggestions);
	suggestModel.setCategoryID('store');
	if(custGroupHelper.isDistributor) {
		suggestModel.setCategoryID(distributorCategory.ID);
	}else{
		suggestModel.addRefinementValues('isDistributor', false);
	}
	if (!suggestModel) {
		return;
	}

	var product = getProductSuggestions(suggestModel);
	
	// app_pagedesigner_sg starts
    var recent = getRecentSearchPhrases(suggestModel);
    var popular = getPopularSearchPhrases(suggestModel);
    // app_pagedesigner_sg ends
	
	var brand = getBrandSuggestions(suggestModel);
	var category = getCategorySuggestions(suggestModel);
	var content = getContentSuggestions(suggestModel);
	var custom = getCustomSuggestions(suggestModel);

	return {
		product: product,
		// app_pagedesigner_sg starts
		recent: recent,
		popular: popular,
		// app_pagedesigner_sg ends
		brand: brand,
		category: category,
		content: content,
		custom: custom
	};
};
