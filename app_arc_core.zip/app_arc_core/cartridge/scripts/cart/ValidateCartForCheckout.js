'use strict';

/**
 * ValidateCartForCheckout
 *
 * This script implements a typical shopping cart checkout validation.
 * The script is provided with the Salesforce Commerce Cloud reference application. Some
 * parts of the validation script are specific to the reference application
 * logic and might not be applicable to our customer's storefront applications.
 * However, the shopping cart validation script can be customized to meet
 * specific needs and requirements.
 *
 * The script implements the validation of the shopping cart against specific
 * conditions. This includes the following steps:
 * - validate that total price is not N/A
 * - validate that all products in the basket are still in site catalog and online
 * - validate that all coupon codes in the basket are valid
 * - validate that the taxes can be calculated for all products in the basket (if ValidateTax in put paramter is true)
 *
 * @input Basket : dw.order.Basket
 * @input ValidateTax : Boolean
 * @output BasketStatus : dw.system.Status
 * @output EnableCheckout : Boolean
 */
var Transaction = require('dw/system/Transaction');
var Utils = require('app_arc_core/cartridge/scripts/checkout/Utils.ds');

function execute (pdict) {
    validate(pdict);

    return PIPELET_NEXT;
}

/**
 * Function: validate
 *
 * Main function of the validation script.
 *
 * @param {dw.system.PipelineDictionary} pdict
 * @param {dw.order.Basket} pdict.Basket
 * @param {Boolean} pdict.ValidateTax
 * @returns {dw.system.Status}
 */
function validate(pdict) {
    var Status = require('dw/system/Status');

    // ===================================================
    // =====     	PROCESS INPUT PARAMETERS 		 =====
    // ===================================================

    // type: dw.order.Basket
    var basket = pdict.Basket;
    // type: Boolean
    var validateTax = pdict.ValidateTax;

    // ===================================================
    // =====   VALIDATE PRODUCT EXISTENCE            =====
    // ===================================================
    // Check if all products in basket can still be resolved
    // and are online

    var productExistence = validateProductExistence(basket, pdict);

    // ===================================================
    // =====             VALIDATE CONTENT            =====
    // ===================================================
    // Check if basket contains products or gift certificates
    var hasContent = validateContent(basket);

    // ===================================================
    // =====    CHECK MERCHANDIZE TOTAL NET PRICE   ======
    // ===================================================

    // Checks the availability of the basket's merchandize
    // total price (net or gross depending on taxation policy)
    var pricesAvailable = basket.merchandizeTotalPrice.available;

    // ===================================================
    // =====             VALIDATE COUPONS           ======
    // ===================================================
    var allCouponsValid = validateCoupons(basket, pdict);

    // ===================================================
    // =====             VALIDATE TAXES             ======
    // ===================================================
    var hasTotalTax = true;
    if (validateTax !== null && validateTax === true) {
        hasTotalTax = basket.totalTax.available;
    }


    // ===================================================
    // =====           EVALUATE CONDITIONS           =====
    // ===================================================

    if (!pricesAvailable || !productExistence) {
        // there are either any product line items without existing
        // product or one or more line items has no price
        pdict.BasketStatus = new Status(Status.ERROR);
        return PIPELET_ERROR;
    } else if (!allCouponsValid) {
        // there are invalid coupon line items.
        // exit with an error.
        pdict.BasketStatus = new Status(Status.ERROR, 'CouponError');
        return PIPELET_ERROR;
    } else if (!hasContent) {
        // there are neither products nor gift certificates in the
        // basket; we exit with an error however the basket status is OK
        pdict.BasketStatus = new Status(Status.OK);
        return PIPELET_ERROR;
    } else if (!hasTotalTax) {
        pdict.BasketStatus = new Status(Status.ERROR, 'TaxError');
        return PIPELET_ERROR;
    }
    
    //


    // ===================================================
    // =====            DONE                         =====
    // ===================================================

    return {
        BasketStatus: new Status(Status.OK),
        EnableCheckout: pdict.EnableCheckout
    };
}

/**
 * FUNCTION: validateProductExistence
 * @param {dw.order.Basket} basket
 * @param {dw.system.PipelineDictionary} pdict
 */
function validateProductExistence(basket, pdict) {
    var quantityOverflow = true;
    //var lmserror = true;
    var datePassed = true;
    var noofClassesInCart = 0;
    var noofvalidClassesInCart = 0;
    var noofproductsInCart = 0;
    var noofinvalidClassesInCart = 0;
    var noofinvalidProductsInCart = 0;
    var lmsCouponError = '';
    var isCartIsValid = true;
    var prodArray = '';
    var invalidProducts = new dw.util.ArrayList();
    var exceedsQtyProducts =  new dw.util.ArrayList();
    var className : dw.util.LinkedHashMap = new dw.util.LinkedHashMap();
    var result = {};
    
    
    // type: Iterator
    var plis = basket.getProductLineItems().iterator();

    var orderLevel = basket.getAdjustedMerchandizeTotalPrice(false).valueOrNull;

    var totalPrice =  basket.getMerchandizeTotalGrossPrice().valueOrNull;
          	
    while (plis.hasNext()) {
        var ProductInventoryMgr = require('dw/catalog/ProductInventoryMgr');
        var StoreMgr = require('dw/catalog/StoreMgr');
       
        // type: dw.order.ProductLineItem
        var pli = plis.next();
        if (pli.product === null || !pli.product.online) {
            return false;
        }
             	
        if (pli.product.custom.IsCourse) {
        	
        	noofClassesInCart++;
        	var listPrice = pli.getBasePrice().getDecimalValue();
        	var startTimeStamp = pli.product.custom.CourseDates[0];
            var curDate = Utils.currentDate();
        	//Order total for SABA
        	var proratedPrice = pli.getAdjustedPrice().getDecimalValue();
        	//var discountsMap = pli.getProratedPriceAdjustmentPrices();
        	var totalDiscount = 0.00;
        	var offeringID = '';
	    	/*var clis = basket.getCouponLineItems().iterator();
	
    	    while (clis.hasNext()) {   	       
    	        var cli = clis.next();
    	    }*/
        	if(!empty(pli.product.custom.SabaOfferingId)){
        		offeringID = pli.product.custom.SabaOfferingId;
        	}
        	/*if (!discountsMap.empty) {
        		 var discounts = discountsMap.entrySet();
        		 var discountsItr = discounts.iterator();
        		 while (discountsItr.hasNext()) {
        			   var discount = discountsItr.next();
        			   var discountAmount = discount.getValue().getDecimalValue();
        			   totalDiscount = -(totalDiscount + discountAmount);
        		 }
        	}*/
         	totalDiscount = listPrice - proratedPrice;
         	var lmsDiscount = totalDiscount.toFixed(2);
        	var lmsCouponId = '';
        	var lmsrealCoupon = '';
        	if(basket.couponLineItems.length > 0){
        		  lmsCouponId = !empty(basket.couponLineItems[0].couponCode) ? basket.couponLineItems[0].couponCode : '';	
        	} else{
        		lmsCouponId = '';
        	}
        	
        	let coupons = new Array();
        	
    		var couponlineitemlist : Iterator = basket.getCouponLineItems().iterator();
        	for each(var cli : CouponLineItem in couponlineitemlist) {
            	priceadjustments = cli.getPriceAdjustments().iterator();
            	for each(var priceadjustment : PriceAdjustment in priceadjustments) {
                	var promotion: Promotion = priceadjustment.getPromotion();
                	var promotionclass: String = promotion.getPromotionClass();
                 	if(priceadjustment.basedOnCoupon && !promotion.custom.dwpromo) {
                    	    var productcouponcode : String= cli.getCouponCode();
                        	 if(productcouponcode!=null && productcouponcode == lmsCouponId){
                        		 coupons.push(productcouponcode);
                        		 lmsrealCoupon = productcouponcode;
                       	  }
                	 }
            	}
       		 }
    		         	
         	var params = {
    	        	offeringId : offeringID,   
    	        	listPrice : listPrice,
    	        	totalDiscount : lmsDiscount,
    	        	proratedPrice : proratedPrice,
    	        	lmsCouponId : lmsrealCoupon
        	};
        	//error logs induced to indentify the cause for 
        	
         	if((new Date(new Number(startTimeStamp)) <= curDate)){
	    	    className.put(startTimeStamp,pli.product.ID);
	    	     isCartIsValid =  false;
	             datePassed = true;
	             noofinvalidClassesInCart++;
	        } else{ 
	        	noofvalidClassesInCart++;
	        	//Saba call to validate the inventory
 	        	 var lmsCreateStatus = require('app_arc_services/cartridge/controllers/Lms').validateCheckOrderLoad(params);
 	        	if(!empty(lmsCreateStatus) && !empty(lmsCreateStatus.status) && lmsCreateStatus.status.code != 100){
	        		if(lmsCreateStatus.status.code == 2002){
 	        		quantityOverflow =  true;
	        			for (var i = 0 ; i < basket.couponLineItems.length ; i ++){
	        				var cli = basket.couponLineItems[i];
	        				var coupon = cli.couponCode;
	        				if(lmsCouponId == coupon){
	        					 Transaction.wrap(function () {
 	             	              basket.removeCouponLineItem(cli);
	             	            });
	        					// break;
	        				}
	        			}
	        			lmsCouponError = 'SABA coupon is not valid';
	        		} else {
	        			quantityOverflow =  true;
	        		}
	        		
  	        	} 
	        }
  	       
        }
        
        
        var  isItCourse = 'IsCourse' in pli.product.custom &&  pli.product.custom.IsCourse ;
        var  isItCertificate = 'isPrintCertificate' in pli.product.custom && pli.product.custom.isPrintCertificate;
         
        if(!isItCourse && !isItCertificate){
    		noofproductsInCart++;
    	}
       
        //RAP-2490 : if this pli is marked as an instore item use the store inventory instead of the default inventory when diabling the cart based on inventory levels
        if (pli.custom.hasOwnProperty('fromStoreId') && !empty(pli.custom.fromStoreId)) {
            // type: dw.catalog.Store
            var store = StoreMgr.getStore(pli.custom.fromStoreId);
            // type: dw.catalog.ProductInventoryList
            var storeinventory = ProductInventoryMgr.getInventoryList(store.custom.inventoryListId);
            if(!isItCourse && !isItCertificate && !empty(storeinventory.getRecord(pli.productID)) && storeinventory.getRecord(pli.productID).ATS.value >= pli.quantityValue){
            	quantityOverflow = quantityOverflow && (!empty(storeinventory.getRecord(pli.productID)) && storeinventory.getRecord(pli.productID).ATS.value >= pli.quantityValue);
            } else {
            	isCartIsValid =  false;
            }
        } else {
        // RAP-116 : if atleast one of the products is out of stock, don't allow checkout
            // type: dw.catalog.ProductAvailabilityLevels
            var availabilityLevels = pli.product.getAvailabilityModel().getAvailabilityLevels(pli.quantityValue);
            if(!isItCourse && !isItCertificate && availabilityLevels.getNotAvailable().value != 0){
        		var availbleStock = availabilityLevels.getInStock().value + availabilityLevels.getBackorder().value;
        	   if((availabilityLevels.getInStock().value > 0  || availabilityLevels.getBackorder().value > 0 ) && 	availbleStock < pli.quantity.value){
        		   exceedsQtyProducts.add(pli.product);
    			   isCartIsValid =  false;	
        		}else{
        		   noofinvalidProductsInCart++;
              	   isCartIsValid =  false;	
        		}
         	}
            quantityOverflow = quantityOverflow && (availabilityLevels.getNotAvailable().value === 0);
         }
    }
    
  
    //------------ new logic ------------
   
    result.noofClassesInCart = noofClassesInCart;
    result.noofvalidClassesInCart = noofvalidClassesInCart;
    result.noofinvalidClassesInCart = noofinvalidClassesInCart;
    result.noofinvalidProductsInCart = noofinvalidProductsInCart; 
    result.className = className;
    result.exceedsQtyProducts = exceedsQtyProducts;
    result.quantityOverflow = quantityOverflow;
    result.lmsCouponError = lmsCouponError;
    result.isCartIsValid = isCartIsValid;
    //------------ new logic ------------
    pdict.EnableCheckout = result;
    
    if(datePassed){
    	result.datePassed = datePassed;
    	result.className = className;
    	pdict.EnableCheckout  = result;
    }

    return true;
}

/**
 * Validates basket content
 * @param {dw.order.Basket} basket
 *
 */
function validateContent(basket) {
    // type: dw.util.Collection
    var plis = basket.getProductLineItems();
    // type: dw.util.Collection
    var gclis = basket.getGiftCertificateLineItems();

    return (plis.size() === 0 && gclis.size() === 0) ? false : true;
}

/**
 * Validates coupons
 *
 * @param {dw.order.Basket} basket
 */
function validateCoupons(basket) {
    // type: Iterator
    var clis = basket.getCouponLineItems().iterator();

    while (clis.hasNext()) {
        // type: dw.order.CouponLineItem
        var cli = clis.next();
        if (!cli.isValid()) {
            return false;
        }
    }

    return true;
}

module.exports = {
    execute: execute,
    validate: validate
};
