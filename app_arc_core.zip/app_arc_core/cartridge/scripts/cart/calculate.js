'use strict';

/**
 * @module calculate.js
 *
 * This javascript file implements methods (via Common.js exports) that are needed by
 * the new (smaller) CalculateCart.ds script file.  This allows OCAPI calls to reference
 * these tools via the OCAPI 'hook' mechanism
 *
 */
var HashMap = require('dw/util/HashMap');
var PromotionMgr = require('dw/campaign/PromotionMgr');
var ShippingMgr = require('dw/order/ShippingMgr');
var ShippingMethod = require('dw/order/ShippingMethod');
var ShippingLocation = require('dw/order/ShippingLocation');
var TaxMgr = require('dw/order/TaxMgr');
var Logger = require('dw/system/Logger');
var Status = require('dw/system/Status');
var app = require('app_arc_controllers/cartridge/scripts/app');
/* Vertex */
var Vertex = require('int_vertex/cartridge/scripts/vertex');
var VertexHelper = require('int_vertex/cartridge/scripts/helper/helper');
var VertexAPI = require('int_vertex/cartridge/scripts/lib/libVertexApi');
var BasketMgr = require('dw/order/BasketMgr');
var Transaction = require('dw/system/Transaction');
var Site = require('dw/system/Site');

/**
 * @function calculate
 *
 * calculate is the arching logic for computing the value of a basket.  It makes
 * calls into cart/calculate.js and enables both SG and OCAPI applications to share
 * the same cart calculation logic.
 *
 * @param {object} basket The basket to be calculated
 */
exports.calculate = function (basket, skipVertexTax) {
    // ===================================================
    // =====   CALCULATE PRODUCT LINE ITEM PRICES    =====
    // ===================================================

    calculateProductPrices(basket);

    // ===================================================
    // =====    CALCULATE GIFT CERTIFICATE PRICES    =====
    // ===================================================

    calculateGiftCertificatePrices(basket);

    // ===================================================
    // =====   Note: Promotions must be applied      =====
    // =====   after the tax calculation for         =====
    // =====   storefronts based on GROSS prices     =====
    // ===================================================

    // ===================================================
    // =====   APPLY PROMOTION DISCOUNTS			 =====
    // =====   Apply product and order promotions.   =====
    // =====   Must be done before shipping 		 =====
    // =====   calculation. 					     =====
    // ===================================================

    PromotionMgr.applyDiscounts(basket);

    // ===================================================
    // =====        CALCULATE SHIPPING COSTS         =====
    // ===================================================

    // apply product specific shipping costs
    // and calculate total shipping costs
    ShippingMgr.applyShippingCost(basket);
       	
    //calculate total shipping costs from FedEx or USPS
    var availShipments = basket.shipments; 
    if(!empty(availShipments)) {
		for(var i = 0; i < availShipments.length; i++){
			if(availShipments[i].custom.IsCourse){
				continue;
			} else if(availShipments[i].custom.isPrintCertificate){
				continue;
			}	
			
			//if(!availShipments[i].custom.IsCourse){
				var	rateMapObj = JSON.parse(session.privacy.rateMap);
				var hashRateMap = new dw.util.HashMap();
				for each (rateMap in rateMapObj) {
					hashRateMap.put(rateMap.shippingMethod, rateMap.shippingData.price);
				}
				var method : ShippingMethod = availShipments[i].shippingMethod;
				var serviceType = (!empty(method) && !empty(method.custom.serviceType) && method.custom.serviceType.value != null) ? method.custom.serviceType.value : null;
				if (!empty(hashRateMap) && hashRateMap instanceof dw.util.Map) {
					if (!rateMap.empty) {
						var currencyCode = dw.system.Site.getCurrent().getDefaultCurrency();
						var tax = new dw.value.Money(new Number(0),currencyCode);
						if (!empty(serviceType)) {
							var shipcost  = hashRateMap.get(serviceType);
							if (!empty(shipcost)){
								var defShipment = availShipments[i];
								var shippingLineItem = defShipment.getShippingLineItems().iterator();
								var shiplineItem;
								while (shippingLineItem.hasNext()) {
									shiplineItem = shippingLineItem.next();
									shiplineItem.setPriceValue(shipcost);
									//Commented below line as its overriding shipping tax value which is returned from vertex service
									//shiplineItem.updateTax(tax.value);
								}
							}
						}
					}
				}
											 
			//}  
						
		}
    }
    
    // ===================================================
    // =====   APPLY PROMOTION DISCOUNTS			 =====
    // =====   Apply product and order and 			 =====
    // =====   shipping promotions.                  =====
    // ===================================================

    PromotionMgr.applyDiscounts(basket);

    // since we might have bonus product line items, we need to
    // reset product prices
    calculateProductPrices(basket);

    // ===================================================
    // =====         CALCULATE TAX                   =====
    // ===================================================
    
    var internal = false;
    if(customer.authenticated && customer.registered) {
    	var groups = customer.getCustomerGroups();
    	for (var i = 0; i < groups.length; i++) {
            if (groups[i].ID == 'Internal Procurement Group') {
                internal = true;
                break;
            }
        }
    }
    
    // native calculateTax function will be invoked in case if Vertex Service is OFF
    // or any error will be appear.
    // Quotation request will be invoked only after "singleshipping" form is full filled
    var form = null;
    if (session.forms.singleshipping) {
        form = session.forms.singleshipping.shippingAddress.addressFields;
    } else if(session.forms.billing.billingAddress) {
    	form = session.forms.billing.billingAddress.addressFields;
    }
    var isAvailableShipAddress = (form.address1.value && form.city.value) ? true : false;
    
    if(Vertex.isEnabled() && ((!empty(skipVertexTax) && !skipVertexTax)) && !internal) {
    	if (isAvailableShipAddress) {
    		// Compare basket state hash
            var isValidHash = false;
            if (Vertex.isHashEnabled()) {
            	var cachedBasketHash = session.privacy['taxRequestHash'];
                var currentBasketHash = VertexHelper.getBasketHash(basket);
                //isValidHash = cachedBasketHash === currentBasketHash;
            }
            if (!isValidHash) {
            	// Trigger service API
            	session.forms.singleshipping.fulfilled.value = true;
            	var taxCalculated = Vertex.CalculateTax('Quotation', basket);
            	if(!(taxCalculated.result)) {
            		// fallback logic executes with default tax class.
            		calculateTax(basket);
            	}
            	// Add basket hash to track its modifications
                session.privacy['taxRequestHash'] = currentBasketHash;
            }
    	}
    } else if ((!empty(skipVertexTax) && !skipVertexTax) && !internal) {
    	calculateTax(basket);
    } else {
    	if(internal) {
    		VertexAPI.resetTaxes(basket);
    	}
    }
    
    // added order total in Amount Ordered and Registered user or an Unregistered user for PHSSECOM-1181 (By placing order from customer service center)
    addingAmoount(basket);
    
    addingOrderBasketType(basket);
    
    // ===================================================
    // =====         CALCULATE BASKET TOTALS         =====
    // ===================================================

    basket.updateTotals();

    // ===================================================
    // =====            DONE                         =====
    // ===================================================
	
    return new Status(Status.OK);
};

/**
 * @function calculateProductPrices
 *
 * Calculates product prices based on line item quantities. Set calculates prices
 * on the product line items.  This updates the basket and returns nothing
 *
 * @param {object} basket The basket containing the elements to be computed
 */
function calculateProductPrices (basket) {
    // get total quantities for all products contained in the basket
    var productQuantities = basket.getProductQuantities();
    var productQuantitiesIt = productQuantities.keySet().iterator();

    // get product prices for the accumulated product quantities
    var productPrices = new HashMap();

    while (productQuantitiesIt.hasNext()) {
        var prod = productQuantitiesIt.next();
        var quantity = productQuantities.get(prod);
        productPrices.put(prod, prod.priceModel.getPrice(quantity));
    }

    // iterate all product line items of the basket and set prices
    var productLineItems = basket.getAllProductLineItems().iterator();
    while (productLineItems.hasNext()) {
        var productLineItem = productLineItems.next();

        // handle non-catalog products
        if (!productLineItem.catalogProduct) {
            productLineItem.setPriceValue(productLineItem.basePrice.valueOrNull);
            continue;
        }

        var product = productLineItem.product;

        // handle option line items
        if (productLineItem.optionProductLineItem) {
            // for bonus option line items, we do not update the price
            // the price is set to 0.0 by the promotion engine
            if (!productLineItem.bonusProductLineItem) {
                productLineItem.updateOptionPrice();
            }
        // handle bundle line items, but only if they're not a bonus
        } else if (productLineItem.bundledProductLineItem) {
            // no price is set for bundled product line items
        // handle bonus line items
        // the promotion engine set the price of a bonus product to 0.0
        // we update this price here to the actual product price just to
        // provide the total customer savings in the storefront
        // we have to update the product price as well as the bonus adjustment
        } else if (productLineItem.bonusProductLineItem && product !== null) {
            var price = product.priceModel.price;
            var adjustedPrice = productLineItem.adjustedPrice;
            productLineItem.setPriceValue(price.valueOrNull);
            // get the product quantity
            var quantity2 = productLineItem.quantity;
            // we assume that a bonus line item has only one price adjustment
            var adjustments = productLineItem.priceAdjustments;
            if (!adjustments.isEmpty()) {
                var adjustment = adjustments.iterator().next();
                var adjustmentPrice = price.multiply(quantity2.value).multiply(-1.0).add(adjustedPrice);
                adjustment.setPriceValue(adjustmentPrice.valueOrNull);
            }


        // set the product price. Updates the 'basePrice' of the product line item,
        // and either the 'netPrice' or the 'grossPrice' based on the current taxation
        // policy

        // handle product line items unrelated to product
        } else if (product === null) {
            productLineItem.setPriceValue(null);
        // handle normal product line items
        } else {
             productLineItem.setPriceValue(productPrices.get(product).valueOrNull);
          }
    }
}

/**
 * @function calculateGiftCertificates
 *
 * Function sets either the net or gross price attribute of all gift certificate
 * line items of the basket by using the gift certificate base price. It updates the basket in place.
 *
 * @param {object} basket The basket containing the gift certificates
 */
function calculateGiftCertificatePrices (basket) {
    var giftCertificates = basket.getGiftCertificateLineItems().iterator();
    while (giftCertificates.hasNext()) {
        var giftCertificate = giftCertificates.next();
        giftCertificate.setPriceValue(giftCertificate.basePrice.valueOrNull);
    }
}

function addingAmoount(basket) {
	basket.custom.amountordered = basket.totalGrossPrice.value;
	basket.custom.isRegistered = customer.registered;    
}

function addingOrderBasketType(basket){

	var basketCombinations = {};
	var pliProductOnly = false, pliCourseOnly = false;
	
	for each(var pli in basket.getAllProductLineItems()){
	  
		  if(pli.custom.IsCourse){
		  	pliCourseOnly = true;
		  	//order.custom.Order_Basket_Type = "OnlineOnly";
		  } else{
		  	pliProductOnly = true;
		  }
		  
		  if(pliCourseOnly && pliProductOnly){  
		  	basket.custom.Order_Basket_Type = "MixedBasket"; 
		  } else if(pliCourseOnly){
		  	basket.custom.Order_Basket_Type = "CourseOnly";
		  } else if(pliProductOnly){
		  	basket.custom.Order_Basket_Type = "ProductOnly";
		  }
	}
}

/**
 * @function calculateTax <p>
 *
 * Determines tax rates for all line items of the basket. Uses the shipping addresses
 * associated with the basket shipments to determine the appropriate tax jurisdiction.
 * Uses the tax class assigned to products and shipping methods to lookup tax rates. <p>
 *
 * Sets the tax-related fields of the line items. <p>
 *
 * Handles gift certificates, which aren't taxable. <p>
 *
 * Note that the function implements a fallback to the default tax jurisdiction
 * if no other jurisdiction matches the specified shipping location/shipping address.<p>
 *
 * Note that the function implements a fallback to the default tax class if a
 * product or a shipping method does explicitly define a tax class.
 *
 * @param {object} basket The basket containing the elements for which taxes need to be calculated
 */
function calculateTax (basket) {
    //Split shipment when cart contains Mixed Basket products.
    splitShipments(basket);
    
    if(basket.shipments.length === 1) {
    	createShippingAddressForShipments(basket);
    }
    
	var shipments = basket.getShipments().iterator();
    while (shipments.hasNext()) {
        var shipment = shipments.next();

        // first we reset all tax fields of all the line items of the shipment
        var shipmentLineItems = shipment.getAllLineItems().iterator();
        while (shipmentLineItems.hasNext()) {
            var _lineItem = shipmentLineItems.next();
            // do not touch tax rate for fix rate items
            if (_lineItem.taxClassID === TaxMgr.customRateTaxClassID) {
                _lineItem.updateTax(_lineItem.taxRate);
            } else {
                _lineItem.updateTax(0.0);
            }
        }

        // identify the appropriate tax jurisdiction
        var taxJurisdictionID = null;

        // if we have a shipping address, we can determine a tax jurisdiction for it
        if (shipment.shippingAddress !== null) {
            var location = new ShippingLocation(shipment.shippingAddress);
            taxJurisdictionID = TaxMgr.getTaxJurisdictionID(location);
        }

        if (taxJurisdictionID === null) {
            taxJurisdictionID = TaxMgr.defaultTaxJurisdictionID;
        }

        // if we have no tax jurisdiction, we cannot calculate tax
        if (taxJurisdictionID === null) {
            continue;
        }

        // shipping address and tax juridisction are available
        var shipmentLineItems2 = shipment.getAllLineItems().iterator();
        while (shipmentLineItems2.hasNext()) {
            var lineItem = shipmentLineItems2.next();
            var currencyCode = dw.system.Site.getCurrent().getDefaultCurrency();
            var taxClassID = lineItem.taxClassID;

            // do not touch line items with fix tax rate
            if (taxClassID === TaxMgr.customRateTaxClassID) {
                continue;
            }

            // line item does not define a valid tax class; let's fall back to default tax class
            if (taxClassID === null) {
                taxClassID = TaxMgr.defaultTaxClassID;
            }

            // if we have no tax class, we cannot calculate tax
            if (taxClassID === null) {
                Logger.debug('Line Item {0} has invalid Tax Class {1}', lineItem.lineItemText, lineItem.taxClassID);
                continue;
            }
        
        	var shippingState = shipment.shippingAddress.stateCode;
			var taxExemptionId = '';
			// Get user tax exemption id
		    if(session.forms.singleshipping.shippingAddress.taxExemptionId != undefined && !empty(session.forms.singleshipping.shippingAddress.taxExemptionId.value)) {
		    	taxExemptionId = session.forms.singleshipping.shippingAddress.taxExemptionId.value;
		    }
			if(empty(taxExemptionId)) {
				if('taxExemptionId' in session.privacy && !empty(session.privacy.taxExemptionId) && session.privacy.taxExemptionId != null) {
					taxExemptionId = session.privacy.taxExemptionId;
				}
			}
			// Update specific line items (refactored from Vertex tax calculation)
            var className = lineItem.constructor.name;
			if(className == 'dw.order.ProductLineItem') {
				 taxClassID = lineItem.product.custom.productTaxClass;
				 if(!empty(taxClassID)) {
					 taxClassID = TaxMgr.defaultTaxClassID;
				 } else {
					 taxClassID = 'baseTax';
				 }
				 if(lineItem.custom.IsCourse && !empty(lineItem.product.custom.CourseFormat) && lineItem.product.custom.CourseFormat.value.toLowerCase() != 'online' && !empty(lineItem.product.custom.FacilityID)) {
					 var facId = lineItem.product.custom.FacilityID;
		             var store : dw.catalog.Store = dw.catalog.StoreMgr.getStore(facId);
					 if(!empty(store) && !empty(store.getName()) && !empty(store.getAddress1()) && !empty(store.getPostalCode())){
						 var location = new ShippingLocation();
						 
						 location.setCountryCode('US');
						 location.setStateCode(store.getStateCode());
						 location.setPostalCode(store.getPostalCode());
						 location.setCity(store.getCity());
						 location.setAddress1(store.getAddress1());
						 location.setAddress2(store.getAddress2());
						 //TSED-786: fix for sales Tax applied on nontaxable states for the courses when Vertex Service is Disabled.
						 var billingState = store.getStateCode();
						 if ('taxableStateForCourses' in Site.getCurrent().preferences.custom && Site.getCurrent().preferences.getCustom().taxableStateForCourses != '') {
							 var parsedJSON = JSON.parse(Site.getCurrent().preferences.getCustom().taxableStateForCourses);
							 for (var prop in parsedJSON) {
								 var statecode = parsedJSON[prop];
								 if(billingState == statecode) {
									 taxJurisdictionID = TaxMgr.getTaxJurisdictionID(location);
								     break;
								 } else {
									 taxJurisdictionID = TaxMgr.defaultTaxJurisdictionID;
								 }
							 }
						 } else {
							 taxJurisdictionID = TaxMgr.defaultTaxJurisdictionID;
						 }
					 } 
				 } else if((lineItem.custom.IsCourse && !empty(lineItem.product.custom.CourseFormat) && lineItem.product.custom.CourseFormat.value.toLowerCase() == 'online') || lineItem.product.custom.isDigital) {
					 var location = new ShippingLocation();
					 
					 location.setCountryCode('US');
					 location.setStateCode(session.forms.billing.billingAddress.addressFields.states.state.value);
					 location.setPostalCode(session.forms.billing.billingAddress.addressFields.postal.value);
					 location.setCity(session.forms.billing.billingAddress.addressFields.city.value);
					 location.setAddress1(session.forms.billing.billingAddress.addressFields.address1.value);
					 location.setAddress2(session.forms.billing.billingAddress.addressFields.address2.value);
					//TSED-786: fix for sales Tax applied on nontaxable states for the courses when Vertex Service is Disabled.
					 var billingState = session.forms.billing.billingAddress.addressFields.states.state.value;
					 if ('taxableStateForCourses' in Site.getCurrent().preferences.custom && Site.getCurrent().preferences.getCustom().taxableStateForCourses != '' && lineItem.custom.IsCourse) {
						 var parsedJSON = JSON.parse(Site.getCurrent().preferences.getCustom().taxableStateForCourses);
						 for (var prop in parsedJSON) {
							 var statecode = parsedJSON[prop];
							 if(billingState == statecode) {
								 taxJurisdictionID = TaxMgr.getTaxJurisdictionID(location);
							     break;
							 } else {
								 taxJurisdictionID = TaxMgr.defaultTaxJurisdictionID;
							 }
						 }
					 } else {
						 taxJurisdictionID = TaxMgr.getTaxJurisdictionID(location);
					 }
				 } else {
					 if (shipment.shippingAddress !== null) {
						 var location = new ShippingLocation(shipment.shippingAddress);
				         taxJurisdictionID = TaxMgr.getTaxJurisdictionID(location);
				     }
				 }
				 
				 // get the tax rate
				 var taxRate = TaxMgr.getTaxRate(taxClassID, taxJurisdictionID);
				 // w/o a valid tax rate, we cannot calculate tax for the line item
				 if (taxRate === null) {
					 continue;
				 }
				 
				 var taxBasis = lineItem.price.value;
				 // If this line has a discount, use the prorated discount price for the tax basis
				 if(taxBasis != lineItem.proratedPrice.value) {
					 taxBasis = lineItem.proratedPrice.value;
				 }
				 
				 var taxableBasis = new dw.value.Money(taxBasis, currencyCode);
				 var taxAmount = (new dw.value.Money(taxBasis, currencyCode)).multiply(taxRate);
				 if (TaxMgr.getTaxationPolicy() == TaxMgr.TAX_POLICY_GROSS) {
					 lineItem.updateTax(taxRate, (taxableBasis.subtract(taxAmount)));
				 } else {
					 lineItem.updateTax(taxRate, taxableBasis);
				 }
				 // calculate the tax of the line item
				 lineItem.updateTaxAmount(taxAmount);
				 lineItem.custom.productLineItemTaxWithoutAddon = taxAmount.value;
				 
				 // Validate Tax exemption ID
				 if(!empty(taxExemptionId) && taxExemptionId && !empty(shippingState) && shippingState != null) {
					 var taxExemptionID = taxExemptionId;
	            	 taxExemptionId = VertexHelper.getUserTaxExemptionId(basket, lineItem, taxExemptionId, shippingState);
	            	 if(!empty(taxExemptionId)) {
	            		 lineItem.updateTax(0.00);
	            		 lineItem.updateTaxAmount(new dw.value.Money(new Number(0),currencyCode));
	            		 lineItem.custom.productLineItemTaxWithoutAddon = 0.00;
	            		 //Update tax exemption flag and tax exemption is at product line-item level.
	            		 lineItem.custom.taxExemptionFlag = true;
	            		 lineItem.custom.taxExemptID = taxExemptionID;
	            	 } else {
	            		 lineItem.updateTaxAmount(taxAmount); 
	            	 }
				 }
			} else if (className == 'dw.order.ShippingLineItem') {
				//taxClassID = TaxMgr.defaultTaxClassID;
				// get the tax rate
				var productLineItems = shipment.productLineItems;
				for (var i = 0; i < productLineItems.length; i++) {
					var pli = productLineItems[i];
					if(!empty(pli.product.custom.productTaxClass)) {
						taxClassID = TaxMgr.defaultTaxClassID;
						break;
					} else {
						 taxClassID = 'baseTax';
					}
            	}
				var taxRate = TaxMgr.getTaxRate(taxClassID, taxJurisdictionID);
				if (taxRate === null) {
	                continue;
	            }
				var taxBasis = shipment.shippingLineItems[0].price.value;
				// If this line has a discount, use the discount price for the tax basis
				if (taxBasis !== shipment.shippingLineItems[0].adjustedPrice.value) {
					taxBasis = shipment.shippingLineItems[0].adjustedPrice.value;
				}
				var taxable = new dw.value.Money(taxBasis, currencyCode);
				var taxAmount = (new dw.value.Money(taxBasis, currencyCode)).multiply(taxRate);
				
				// calculate the tax of the line item
				lineItem.updateTax(taxRate, taxable);
				lineItem.updateTaxAmount(taxAmount);
				lineItem.custom.shippingTaxAmountWithoutAddon = taxAmount.value;
				
				// Validate Tax exemption ID
				var productlineitems = shipment.productLineItems;
				for (var i = 0; i < productlineitems.length; i++) {
					var pli = productlineitems[i];
					if(!empty(taxExemptionId) && taxExemptionId && !empty(shippingState) && shippingState != null && pli.custom.taxExemptionFlag) {
						lineItem.updateTax(0.00);
						lineItem.updateTaxAmount(new dw.value.Money(new Number(0),currencyCode));
						lineItem.custom.shippingTaxAmountWithoutAddon = 0.00;
					}
				}
			} else {
				// price adjustments...
				lineItem.updateTax(0.00);
			}
        }
    }

    // besides shipment line items, we need to calculate tax for possible order-level price adjustments
    // this includes order-level shipping price adjustments
    if (!basket.getPriceAdjustments().empty || !basket.getShippingPriceAdjustments().empty) {
    // calculate a mix tax rate from
    var basketPriceAdjustmentsTaxRate = (basket.getMerchandizeTotalGrossPrice().value / basket.getMerchandizeTotalNetPrice().value) - 1;

        var basketPriceAdjustments = basket.getPriceAdjustments().iterator();
        while (basketPriceAdjustments.hasNext()) {
            var basketPriceAdjustment = basketPriceAdjustments.next();
            basketPriceAdjustment.updateTax(0.00);
        }
        
        var basketShippingPriceAdjustments = basket.getShippingPriceAdjustments().iterator();
        while (basketShippingPriceAdjustments.hasNext()) {
            var basketShippingPriceAdjustment = basketShippingPriceAdjustments.next();
            basketShippingPriceAdjustment.updateTax(0.00);
        }
    }
}
/**
 * @function splitShipments <p>
 * Splits shipments when basket contains wallet certificate with other product combinations.
 * @param {object} basket
 */
function splitShipments(basket) {
	var productLineItems = basket.productLineItems;
	var isPrintCertificate = false;
	var isCourse = false;
    var isDigital = false;
    var isProduct = false;
    
    if(basket.productLineItems.length > 1) {
    	var productLineItems = basket.productLineItems;
    	var isPrintCertificate = false;
    	var isCourse = false;
        var isDigital = false;
        var isProduct = false;
        var isClassroomBlendExist = false;
    	for (var i = 0; i < productLineItems.length; i++) {
    		var productLineitem = productLineItems[i];
    		if(productLineitem.custom.isPrintCertificate) {
    			isPrintCertificate = true;
    		} else if(productLineitem.custom.IsCourse) {
    			isCourse = true;
    			if(!empty(productLineitem.product.custom.CourseFormat) && productLineitem.product.custom.CourseFormat.value.toLowerCase() != 'online'){
    				isClassroomBlendExist = true;
    			}
    		} else if(productLineitem.product.custom.isDigital) {
    			isDigital = true;
    		} else {
    			isProduct = true;
    		}
    	}
    	if(isProduct && !isCourse && !isDigital && !isPrintCertificate) {
    		//don't split the shipment
    	} else if(productLineItems.length > 1 && isCourse && isClassroomBlendExist && !isProduct && !isDigital && !isPrintCertificate) {
    		//don't split the shipment
    	} else if((isDigital || isCourse) && isPrintCertificate && !isProduct) {
    		//don't split the shipment
    	} else if(productLineItems.length > 1 && isCourse && !isClassroomBlendExist && !isProduct && !isDigital && !isPrintCertificate) {
    		//don't split the shipment when basket contains more than one online course products
    	} else if(productLineItems.length > 1 && isDigital && !isCourse && !isProduct && !isPrintCertificate) {
    		//don't split the shipment when basket contains more than one digital products
    	} else if(productLineItems.length > 1 && isPrintCertificate && !isCourse && !isProduct && !isDigital) {
    		//don't split the shipment when basket contains more than one wallet certificate products
    	} else if(productLineItems.length > 1 && isCourse && isDigital && !isProduct && !isPrintCertificate) {
    		//don't split the shipment when basket contains only online and digital products
    	} else {
    		VertexHelper.splitShipments(basket);
    	}
    }
    
}
/**
 * @function createShippingAddressForShipments <p>
 * Creates shipping address to the shipment for the user entered address in the form field.
 * This address will be used to determine a tax jurisdiction
 * @param {object} basket
 */
function createShippingAddressForShipments(basket) {
	var cart = app.getModel('Cart').get();
	var shipments = basket.getShipments().iterator();
    var shippingAddress;
    while (shipments.hasNext()) {
    	var shipment = shipments.next();
		shippingAddress = cart.createShipmentShippingAddress(shipment.getID());
    	shippingAddress.setFirstName(session.forms.singleshipping.shippingAddress.addressFields.firstName.value);
		shippingAddress.setLastName(session.forms.singleshipping.shippingAddress.addressFields.lastName.value);
		shippingAddress.setAddress1(session.forms.singleshipping.shippingAddress.addressFields.address1.value);
		shippingAddress.setAddress2(session.forms.singleshipping.shippingAddress.addressFields.address2.value);
		shippingAddress.setCity(session.forms.singleshipping.shippingAddress.addressFields.city.value);
		shippingAddress.setPostalCode(session.forms.singleshipping.shippingAddress.addressFields.postal.value);
		shippingAddress.setStateCode(session.forms.singleshipping.shippingAddress.addressFields.states.state.value);
		shippingAddress.setCountryCode(session.forms.singleshipping.shippingAddress.addressFields.country.value);
		shippingAddress.setPhone(session.forms.singleshipping.shippingAddress.addressFields.phone.value);
		shippingAddress.setCompanyName(session.forms.singleshipping.shippingAddress.companyname.value);
    }
}
